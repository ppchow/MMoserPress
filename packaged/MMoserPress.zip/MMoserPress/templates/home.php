<?php 
/**
* Template Name: Home
*/

remove_filter ('the_content',  'wpautop');
get_header();
?>
  <?php
  
    // Start the loop.
    while ( have_posts() ) : the_post();

      // Include the page content template.
      the_content();
    
    // End the loop.
    endwhile;

 get_footer(); ?>
